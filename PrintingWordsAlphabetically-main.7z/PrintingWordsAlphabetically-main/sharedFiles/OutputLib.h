#ifndef OUTPUT_LIB_H
#define OUTPUT_LIB_H

void AlphabeticalPrinting(char *string, int length);
void PrintString(char *string, int length);

#endif