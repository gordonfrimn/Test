#ifndef WORK_FILES_H
#define WORK_FILES_H

char* ReadTextFile(char *path, int *length);

#endif