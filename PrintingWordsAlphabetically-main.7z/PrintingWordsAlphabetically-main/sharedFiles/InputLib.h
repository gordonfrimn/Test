#ifndef INPUT_LIBS_H
#define INPUT_LIBS_H

char* InputString(int *length);

#endif