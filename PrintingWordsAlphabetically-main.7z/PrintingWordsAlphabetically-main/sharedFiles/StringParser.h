#ifndef STRING_PARSER_H
#define STRING_PARSER_H

int StringPars(char *string, int length);

#endif